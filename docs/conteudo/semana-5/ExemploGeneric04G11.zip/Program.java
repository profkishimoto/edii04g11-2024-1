
public class Program {
	
	public static Generic<Integer, String> f(int value) {
		if (value < 0) {
			return new Generic<Integer, String>(1, "Erro: não pode ter valor negativo.");
		}
		
		return new Generic<Integer, String>(0, Integer.toString(value));
	}

	public static void main(String[] args) {
		Node n = new Node("teste");
		System.out.println("n: " + n);
		
		NodeGeneric<String> ng = new NodeGeneric<String>("teste generic");
		System.out.println("ng: " + ng);
		
		NodeGeneric<Integer> nodeInt = new NodeGeneric<Integer>(99);
		System.out.println("nodeInt: " + nodeInt);
		nodeInt.setData(1000);
		System.out.println("nodeInt.getData(): " + nodeInt.getData());
		
		NodeGeneric<MyData> nodeMyData = new NodeGeneric<MyData>(new MyData(123, "abc"));
		System.out.println("nodeMyData: " + nodeMyData);
		//MyData temp = nodeMyData.getData();
		//temp.setId(999);

		// Method chaining (observe que os setters do MyData retornam this).
		nodeMyData
			.getData()
			.setId(999)
			.setStr("Hello, World!");
		
		System.out.println("nodeMyData: " + nodeMyData);
		System.out.println("nodeMyData.getData().getId(): " + nodeMyData.getData().getId());
		System.out.println("nodeMyData.getData().getStr(): " + nodeMyData.getData().getStr());
		
		Generic<Integer, String> g = new Generic<Integer, String>(0, "xyz");
		System.out.println("g: " + g);
		
		var test = f(10);
		System.out.println(test);
		
		var test2 = f(-1);
		if (test2.getKey() != 0)
			System.out.println(test2.getValue());
	}

}
