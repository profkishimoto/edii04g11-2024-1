
// Classe comum.
public class Node {
	
	private String data;
	private Node parent;
	private Node left;
	private Node right;
	
	public Node() {
		this("");
	}
	
	public Node(String data) {
		this.data = data;
		parent = null;
		left = null;
		right = null;
	}
	
	@Override
	public String toString() {
		return data;
	}

}
