
// Classe comum.
public class MyData {
	
	private int id;
	private String str;
	
	public MyData() {
		this(0, "");		
	}
	
	public MyData(int id, String str) {
		this.id = id;
		this.str = str;
	}
	
	public int getId() {
		return id;
	}
	
	public MyData setId(int id) {
		this.id = id;
		return this;
	}
	
	public String getStr() {
		return str;
	}
	
	public MyData setStr(String str) {
		this.str = str;
		return this;
	}	
	
	@Override
	public String toString() {
		return "id: " + id + ", str: " + str;
	}

}
