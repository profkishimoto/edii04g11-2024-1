package ed2;

public class Pessoa {
	protected String nome;
	protected String endereco;
	private String telefone;
	
	public Pessoa() {
		this("", "", "");
		System.out.println("ctor --> Pessoa()");
	}
	
	public Pessoa(String nome, String endereco, String telefone) {
		System.out.println("ctor --> Pessoa(" + nome + ", " + endereco + ", " + telefone + ")");
		this.nome = nome;
		this.endereco = endereco;
		this.telefone = telefone;
	}
	
	@Override
	public String toString() {
		return nome + "; " + endereco + "; " + telefone;
	}
	
	public String getTelefone() {
		return telefone;
	}
	
}
