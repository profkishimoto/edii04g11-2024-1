package ed2;

public class PessoaFisica extends Pessoa {

	private String cpf;
	
	public PessoaFisica() {
		super();
		this.cpf = "";
		System.out.println("ctor --> PessoaFisica()");
	}
	
	public PessoaFisica(String nome, String endereco, String telefone, String cpf) {
		super(nome, endereco, telefone);
		this.cpf = cpf;
		System.out.println("ctor --> PessoaFisica(" + nome + ", " + endereco + ", " + telefone + ", " + cpf + ")");
	}
	
	@Override
	public String toString() {
		return nome + " --- " + endereco + " --- " + getTelefone() + " --- " + cpf;
	}
	
	public String getCpf() {
		return cpf;
	}
	
}
