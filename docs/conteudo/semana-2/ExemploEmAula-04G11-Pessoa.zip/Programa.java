import ed2.Pessoa;
import ed2.PessoaFisica;

public class Programa {

	public static void main(String[] args) {
//		Pessoa p = new Pessoa("Andre", "Rua xyz", "11...");
//		System.out.println(p);
//		
//		PessoaFisica pf = new PessoaFisica("Pf", "Av. abc", "21", "123.456.789-00");
//		System.out.println(pf);
		
		Pessoa pessoas[] = new Pessoa[4];
		pessoas[0] = new Pessoa();
		pessoas[1] = new Pessoa("p1", "xyz", "123");
		pessoas[2] = new PessoaFisica();
		pessoas[3] = new PessoaFisica("pf2", "qwerty", "999", "999.999.999-99");
		for (Pessoa p : pessoas) {
			System.out.println(p);
			if (p instanceof PessoaFisica) {
				System.out.println("CPF: " + ((PessoaFisica)p).getCpf());
			}
		}
		
//		PessoaFisica temp = (PessoaFisica)pessoas[2];
//		temp.getCpf();
//		((PessoaFisica)pessoas[2]).getCpf();
	}

}
